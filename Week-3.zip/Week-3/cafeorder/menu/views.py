from django.shortcuts import render
from .models import Product


def menu_list(request):
    products = Product.objects.filter(is_available=True)
    return render(request, 'menu/list.html', {'products': products})
